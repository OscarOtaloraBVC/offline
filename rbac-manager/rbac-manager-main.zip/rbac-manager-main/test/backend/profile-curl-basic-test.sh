#!/bin/bash

BASE_URL="http://localhost:8000/api/v1"
ID_TEST=1

echo -e "Testing Create..."
profile="Profile$(date +%s)"
curl -X POST "${BASE_URL}/profiles/" \
     -H "Content-Type: application/json" \
     -d "{\"name\": \"$profile\"}"

echo -e "\n\nTesting List..."
curl -X GET "${BASE_URL}/profiles/"

echo -e "\n\nTesting List..."
curl -X GET "${BASE_URL}/profiles/"

echo -e "\n\nTesting Detail..."
curl -X GET "${BASE_URL}/profiles/$ID_TEST"

echo -e "\n\nTesting Edit..."
curl -X PUT "${BASE_URL}/profiles/$ID_TEST" \
     -H "Content-Type: application/json" \
     -d '{"name": "Super Admin"}'

echo -e "\n\nTesting Delete..."
curl -X DELETE "${BASE_URL}/profiles/3"

echo -e "\n\nTesting save permissions..."
curl -X POST \
  -H "Content-Type: application/json" \
  -d '[
    {
      "resource": "pods",
      "is_verb_get": true,
      "is_verb_list": true,
      "is_verb_watch": false,
      "is_verb_create": true,
      "is_verb_update": false,
      "is_verb_patch": false,
      "is_verb_delete": false,
      "is_verb_deletecollection": false
    },
    {
      "resource": "deployments",
      "is_verb_get": false,
      "is_verb_list": true,
      "is_verb_watch": true,
      "is_verb_create": false,
      "is_verb_update": true,
      "is_verb_patch": true,
      "is_verb_delete": false,
      "is_verb_deletecollection": true
    },
    {
      "resource": "nodes",
      "is_verb_get": true
    }
  ]' \
  "${BASE_URL}/profiles/save-permissions?profile_id=2"


echo -e "\n\nTesting List of permissions..."
curl -X GET "${BASE_URL}/profiles/2/permissions"

echo -e "\n\n :) \n"
