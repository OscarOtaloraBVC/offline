#!/bin/bash

BASE_URL="http://localhost:8000/api/v1"

# echo -e "\n\nTesting List on namespaces...\n"
# curl -X GET "${BASE_URL}/k8s_service/ns"

echo -e "\n\nTesting List on api-resources...\n"
curl -X GET "${BASE_URL}/k8s_service/api-resources"

#echo -e "\n\nTesting: Last Kubeconfig...\n"
#curl -X GET "${BASE_URL}/k8s_service/1/last-kubeconfig"

#echo -e "\n\nTesting: Generate Kubeconfig...\n"
#curl -X GET "${BASE_URL}/k8s_service/1/generate-kubeconfig"

echo -e "\n\n :) \n"