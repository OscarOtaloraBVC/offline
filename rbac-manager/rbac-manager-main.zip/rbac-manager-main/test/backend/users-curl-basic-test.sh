#!/bin/bash

BASE_URL="http://localhost:8000/api/v1"

echo -e "Testing Create..."

#curl -X POST "${BASE_URL}/users/createns" \
#     -H "Content-Type: application/json" \
#     -d "{\"namespace\": \"FFFFFFFFFFFFFFX\",\"user_id\":\"1\"}"


curl -X POST "${BASE_URL}/users/save-ns" \
     -H "Content-Type: application/json" \
     -d "[{\"namespace\": \"FFFFFFFFFFFFFFF\",\"user_id\":\"1\"},{\"namespace\": \"HHHHHHHHHHHHHHHHHHHHHhxxxxx\",\"user_id\":\"1\"}]"

echo -e "\n\n :) \n"