import yamlutil
import argparse
import sys
import os
import subprocess
import base64
import string

GROUP_NAME="dev-team"

def execCmd(cmd):
    print("CMD: "+cmd)
    os.system(cmd)

def printStep(msg):
    print("\n---------------------------------------------------------------")
    print(msg)
    print("---------------------------------------------------------------")

def getConfig():
    # Arguments
    parser = argparse.ArgumentParser(description="Recibe un nombre como parámetro.")
    parser.add_argument("-f", "--config-file", help="Path of file config yaml")
    args = parser.parse_args()

    if args.config_file==None:
        print("Configuration file if requred!")
        print("example: python3 main.py -c \"/path/of/config.yaml\" \n" )
        parser.print_help() 
        sys.exit(1)

    if not args.config_file:
        print("Error: File path is empty!\n")
        sys.exit(1) 

    if not os.path.exists(args.config_file):
        print(f"\nError: File '{args.config_file}' not found.\n")
        sys.exit(1)

    config = yamlutil.load_yaml_as_object(os.path.abspath(args.config_file))
    return config

def createNS(config):
    printStep("Creating namespaces...")
    for ns in config['namespaces-allow-all']:
        check_process = subprocess.run(
            ["kubectl", "get", "namespace", ns],
            capture_output=True,
            text=True,
            check=False # No lanzar excepción si el get falla (ns no existe)
        )
        if check_process.returncode != 0:
            execCmd("kubectl create ns "+str(ns))
        else:
            print(ns+" exist")

def createBindings(config):
    printStep("Creating bindings...")
    
    if config['read-all']:
        namerb="nuam-clusterbinding-read-all-"+config['username']
        check_process = subprocess.run(
            ["kubectl", "get", "clusterrolebinding", namerb],
            capture_output=True,
            text=True,
            check=False # No lanzar excepción si no existe
        )
        if check_process.returncode != 0:
            execCmd("kubectl create clusterrolebinding \""+namerb+"\" --clusterrole=\"nuam-allow-read\" --user=\""+config['username']+"\"")
        else:
            print("ClusterRoleBinding "+namerb+" exist")
    
    
    for ns in config['namespaces-allow-all']:
        nameb="nuam-binding-ns-"+ns+config['username']
        
        res=os.system("kubectl get rolebinding "+nameb+" -n "+ns+" > /dev/null 2>&1")
        if res!=0:
             execCmd("kubectl create rolebinding "+nameb+" --clusterrole=nuam-allow-all --user="+config['username']+" --namespace="+ns)
        else:
             print(nameb+" exist")

def createCerts(config,workdir):  
    printStep("Creating certificates...") 
    execCmd("cd "+workdir+" && openssl genrsa -out "+config['username']+".key 2048")      
    execCmd("cd "+workdir+" && openssl req -new -key "+config['username']+".key -out "+config['username']+".csr -subj \"/CN="+config['username']+"/O="+GROUP_NAME+"\"")      

def createCertificateSigningRequest(config,workdir):
    printStep("Creating CertificateSigningRequest...")
    template_content=""
    template_file_path="./yaml/certificateSigningRequest.yaml"
    with open(template_file_path, 'r') as f:
        template_content = f.read()
    
    csr_name_value='nuam-csr-'+config['username']
    
    fileCsr=workdir+"/"+config['username']+".csr"
    with open(fileCsr, 'rb') as f:
            file_bytes = f.read()
    base64_encoded_bytes = base64.b64encode(file_bytes)
    base64_string_with_wraps = base64_encoded_bytes.decode('ascii').replace('\n', '').replace('\r', '')

    substitutions = {
        'CSR_NAME': csr_name_value,
        'CSR_BASE64': base64_string_with_wraps,
        'CSR_EXP': str(60*60*24*config['cert-days-duration'])
    }
    yaml_template = string.Template(template_content)
    final_yaml_content = yaml_template.substitute(substitutions)
    
    check_process = subprocess.run(
            ["kubectl", "get", "certificatesigningrequest", csr_name_value],
            capture_output=True,
            text=True,
            check=False # No lanzar excepción si no existe
        )
    if check_process.returncode == 0:
        execCmd("kubectl delete certificatesigningrequest "+csr_name_value)
    
    fileCSR=workdir+"/certificateSigningRequest.yaml"
    with open(fileCSR, 'w', encoding='utf-8') as f:
        f.write(final_yaml_content)
    execCmd("kubectl apply -f "+fileCSR)
    execCmd("kubectl certificate approve "+csr_name_value)
    return csr_name_value

def createKubeConfig(config,workdir,csr_name):
    printStep("Creating Kubeconfig...")
    pathCrt=workdir+"/"+config['username']+".crt"
    execCmd("kubectl get csr "+csr_name+" -o jsonpath='{.status.certificate}' | base64 -d > "+pathCrt)
    res = subprocess.run(
        ["kubectl","config","view","--raw","-o","jsonpath={.clusters[0].cluster.server}"],
        capture_output=True,
        text=True,
        check=True
    )
    server=res.stdout

    with os.popen("kubectl config view -o jsonpath='{.contexts[?(@.name==\"'$(kubectl config current-context)'\")].context.cluster}'") as pipe:
        outc = pipe.read()
    cluster=outc.strip()
    
    kubeconfigPath=workdir+"/"+config['username']+".kubeconfig"
    caPath=workdir+"/ca.crt"
    execCmd("kubectl config view --raw -o jsonpath='{.clusters[0].cluster.certificate-authority-data}' | base64 -d > "+caPath)
    cmd="kubectl config set-cluster "+cluster+" " \
        "--server="+server+" " \
        "--certificate-authority="+workdir+"/"+"ca.crt " \
        "--embed-certs=true " \
        "--kubeconfig="+kubeconfigPath+" && "

    cmd+="kubectl config set-credentials "+config['username']+" " \
         "--client-certificate="+workdir+"/"+config['username']+".crt " \
         "--client-key="+workdir+"/"+config['username']+".key " \
         "--embed-certs=true " \
         "--kubeconfig="+kubeconfigPath+" && "

    cmd+="kubectl config set-context "+config['username']+"-context " \
         "--cluster="+cluster+" " \
         "--user="+config['username']+" " \
         "--kubeconfig="+kubeconfigPath+" && "

    cmd+="kubectl config use-context "+config['username']+"-context --kubeconfig="+kubeconfigPath+" && "
    cmd+="kubectl --kubeconfig="+kubeconfigPath+" get ns"
    
    execCmd(cmd)

def main():
    config = getConfig()
    #print(config)
    print("User: "+str(config['username']))

    ##Creating roles
    printStep("Creating/updating roles....")
    execCmd("kubectl apply -f ./yaml/allow-all-clusterrole.yaml")
    execCmd("kubectl apply -f ./yaml/allow-read-clusterrole.yaml")
    
    createNS(config)
    createBindings(config)
   
    workdir="../.credentials/certs-"+config['username']
    execCmd("mkdir -p "+workdir)
    createCerts(config,workdir)
    csr_name=createCertificateSigningRequest(config,workdir)
    createKubeConfig(config,workdir,csr_name)

    print("\nCredentials was generated in: '"+workdir+"'")

    print("\nSuccessful :)\n\n")

main()
