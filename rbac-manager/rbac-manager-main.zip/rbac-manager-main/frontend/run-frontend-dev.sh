#!/bin/bash

WORKDIR=/opt/rbac-manager


cp $WORKDIR/frontend/src/services/api.js.dev $WORKDIR/frontend/src/services/api.js

export REACT_APP_API_BASE_URL="http://localhost:8000/api/v1"
npm start