import React from 'react';
import ReactDOM from 'react-dom/client';
// import './index.css'; // Moved global styles to App.js to ensure load order
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);