#!/bin/bash

docker run -d \
  --name rbac-manager \
  -p 8000:8000 \
  -v rbac-manager-data:/opt/rbac-manager/data \
  -e RBAC_DB_SQLITE3_PATH="/opt/rbac-manager/data/rbac-sqlite3.db" \
  -e RBAC_STATIC_FRONTEND_DIR="/opt/rbac-manager/frontend" \
  -e RBAC_CLUSTER_NAME="k3d-dev" \
  -e RBAC_CLUSTER_URL="https://localhost:6443" \
  rbac-manager:1.0.12
  
docker ps | grep rbac-manager