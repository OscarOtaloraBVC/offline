#!/bin/bash

IMG=rbac-manager:1.0.12

k3d image import $IMG -c nuam-poc1

kubectl apply -k .