#!/bin/bash

WORKDIR=/opt/rbac-manager

IMG=rbac-manager:1.0.12

cp $WORKDIR/frontend/src/services/api.js.prod $WORKDIR/frontend/src/services/api.js
cd $WORKDIR/frontend
npm install
NODE_ENV=production npm run build

cd ..
docker build -t $IMG .
docker images | grep rbac-manage