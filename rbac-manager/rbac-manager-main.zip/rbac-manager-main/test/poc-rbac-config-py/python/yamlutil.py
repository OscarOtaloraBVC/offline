import yaml
import os
from pprint import pprint
def load_yaml_as_object(file_path):
    """
    Loads a YAML file and returns its content as a Python dictionary (object).
    """
    if not os.path.exists(file_path):
        print(f"Error: YAML file '{file_path}' not found.")
        return None

    try:
        with open(file_path, 'r') as stream:
            # yaml.safe_load is crucial for security
            data_object = yaml.safe_load(stream)
        return data_object
    except yaml.YAMLError as exc:
        print(f"Error parsing YAML file '{file_path}':")
        if hasattr(exc, 'problem_mark'):
            mark = exc.problem_mark
            print(f"  Error at line {mark.line + 1}, column {mark.column + 1}")
        else:
            print(f"  {exc}")
        return None
    except Exception as e:
        print(f"An unexpected error occurred while reading '{file_path}': {e}")
        return None