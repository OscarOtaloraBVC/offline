#!/bin/bash

echo -e "\n"
# Check if the configuration file argument is provided
if [ -z "$1" ]; then
    echo "Error: Configuration file path is required."
    echo "example: $0 ../roles/reference-data-user1.yaml"
    echo -e "\n"
    exit 1
fi

fileconfig=$1

echo -e "\n"
echo -e "WARNING: Running this procedure may invalidate the kubeconfigs previously distributed to users.\n"

read -p "Do you want to continue? (Y/N): " answer

answer_upper=$(echo "$answer" | tr '[:lower:]' '[:upper:]')


if [ "$answer_upper" == "Y" ]; then
    cd python
    python3 main.py -f $fileconfig
fi